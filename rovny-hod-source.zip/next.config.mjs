import { PHASE_DEVELOPMENT_SERVER } from 'next/constants.js';

export default (phase) => ({distDir:phase===PHASE_DEVELOPMENT_SERVER?'.next-dev':'.next',serverExternalPackages:['sharp'],poweredByHeader:false, async headers(){return [{source:'/:path*',headers:[{key:'X-Content-Type-Options',value:'nosniff'},{key:'Referrer-Policy',value:'no-referrer'},{key:'X-Frame-Options',value:'DENY'},{key:'Permissions-Policy',value:'camera=(), microphone=(), geolocation=()'}]},{source:'/api/:path*',headers:[{key:'Cache-Control',value:'private, no-store'}]}]}});
